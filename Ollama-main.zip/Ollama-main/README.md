# Ollama
This repo brings numerous use cases from the Open Source Ollama

# Step 1
Go Ahead to https://ollama.ai/ and download the set up file

# Step 2
Install and Start the Software

# Step 3
Clone my Entire Repo on your local device using the command
git clone https://github.com/PromptEngineer48/Ollama.git

# Step 4
The Repo has numerous working case as separate Folders. You can work on any folder for testing various use cases

# Step 5
Join me on my Journey on my youtube channel
https://www.youtube.com/@PromptEngineer48/
